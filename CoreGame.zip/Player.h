#pragma once
#ifndef _PLAYER_
#define _PLAYER_
#include "MovingObject.h"
const int MAX_LEVEL = 7;
class Player : public MovingObject
{
	int health, level;
public:
	Player();
	Player(int x, int y, int health_, int level_);
	int getHealth() { return health; }
	int getLevel() { return level; }
	bool isDead() { return (health == 0); }
	bool isFinish() { return (level == MAX_LEVEL); }
	bool isImpact(const MovingObject*);
	void move(MovingDir);
	void nextLevel() 
	{ 
		if (!isFinish())
			level++; 
	}
	string getName() { return "Player"; }
	friend class Game;
};
#endif // !_PLAYER_