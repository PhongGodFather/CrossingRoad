#include "Player.h"
Player::Player()
{
	x = 0;
	y = 0;
	setVel(5);
	setAnim(dancingAnimator);
	health = 100;
	level = 1;
}
Player::Player(Position pos, int health_, int level_)
{
	x = pos.x;
	y = pos.y;
	setVel(5);
	setAnim(dancingAnimator);
	health = health_;
	level = level_;
}
void Player::move(MovingDir dir)
{
	if (dir == left_) x -= vel;
	else if (dir == right_) x += vel;
	else if (dir == up_) y -= vel;
	else if (dir == down_) y += vel;
	playAnim(); // ??
}
bool Player::isImpact(const MovingObject* nah)
{
	int hit_depth = 2;
	if (x + curImg().getWidth() - hit_depth >= nah->x && x <= nah->x + nah->curImg().getWidth() - hit_depth &&
		y + curImg().getHeight() - hit_depth >= nah->y && y <= nah->y + nah->curImg().getHeight() - hit_depth)
	{
		health -= 10;
		return true;
	}
	return false;
}