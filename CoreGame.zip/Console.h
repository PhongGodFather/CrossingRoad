#pragma once
#ifndef _CONSOLE_
#define _CONSOLE_
#include <iostream>
#include <Windows.h>
#include <conio.h>
#include <thread>
#include <string>
#include <chrono>
#include <vector>

#include "Pictures.h"
using namespace std;
class MyConsole
{
protected:
	CHAR_INFO* screenBuffer;
	int ScreenWidth, ScreenHeight;
	HANDLE ConOut, ConIn;
	SMALL_RECT Window;
	void validate(int& x, int& y);

public:
	MyConsole();
	void BuildConsole(int width_, int height_, int fontSize, short color);
	~MyConsole();
	void addChar(int x, int y, wchar_t k, short col = COLOUR::BG_WHITE | FG_RED);

	void setPosColor(int x, int y, short col = COLOUR::BG_WHITE | FG_RED);
	void FillArea(int x, int y, wchar_t k, int width, int height, short col = COLOUR::BG_WHITE | FG_RED);
	void drawString(int x, int y, wstring k, short color = COLOUR::BG_WHITE | FG_RED);
	void drawStringC(int x, int y, string k, short color = COLOUR::BG_WHITE | FG_RED);
	void drawPicture(int x, int y, const picture k, short color = COLOUR::BG_WHITE | FG_RED);
	void drawButton(int x, int y, wstring text, short color = COLOUR::BG_WHITE | FG_RED);
	void drawBox(int x, int y, int width, int height, short color = COLOUR::BG_WHITE | FG_RED);
	void drawConsole();
	void noCursor();
	void clearConsole(short color = COLOUR::BG_WHITE);
};
#endif // !_CONSOLE_