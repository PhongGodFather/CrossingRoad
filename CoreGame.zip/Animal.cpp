#include "Animal.h"
Bird::Bird(int x_, int y_, MovingDir dir, int vel_)
{
	anim = (dir == left_) ? duckAnimatorLeft : duckAnimatorRight;
	direction = dir;
	x = x_;
	y = y_;
	vel = vel_;
}
void Bird::move(MovingDir dir)
{
	if (!is_moving)
		return;
	if (mov_count == 0)
	{
		mov_count = mov_timer;
		if (dir == left_) x -= vel;
		else if (dir == right_) x += vel;
		else if (dir == up_) y -= vel;
		else if (dir == down_) y += vel;
	}
	else
		mov_count--;
}
Deer::Deer(int x_, int y_, MovingDir dir, int vel_)
{
	anim = (dir == left_) ? deerAnimatorLeft : deerAnimatorRight;
	direction = dir;
	x = x_;
	y = y_;
	vel = vel_; // for car only
}
void Deer::move(MovingDir dir)
{
	if (!is_moving)
		return;
	if (mov_count == 0)
	{
		mov_count = mov_timer;
		if (dir == left_) x -= vel;
		else if (dir == right_) x += vel;
		else if (dir == up_) y -= vel;
		else if (dir == down_) y += vel;
	}
	else
		mov_count--;
}