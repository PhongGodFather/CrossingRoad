#include "MovingObject.h"
MovingObject::MovingObject()
{
	mov_count = mov_timer = Sleep_time; // this is my sleep time
	is_moving = true;
}
void MovingObject::setAnim(const Animation animation)
{
	anim = animation;
}
void MovingObject::playAnim()
{
	anim.play();
}