#pragma once
#ifndef _MOVING_OBJECT_
#define _MOVING_OBJECT_
#include "Animation.h"
const int Sleep_time = 20;
enum MovingDir { left_, right_, up_, down_, idle_ }; // for moving I think :3
class MovingObject //: public Position
{
protected:
	int x, y;
	Animation anim;
	int vel, mov_count, mov_timer;
	MovingDir direction;
public:
	picture curImg() const { return anim.getCurFrame(); }
	picture preImg() const { return anim.getPreFrame(); }
	void setAnim(const Animation);
	short getColor() { return anim.getCol(); }
	void playAnim();
	bool is_moving;
	MovingObject();
	int velocity() { return vel; }
	void setVel(int k) { vel = k; }
	MovingDir getDir() { return direction; }
    virtual void move(MovingDir) = 0;
	virtual string getName() = 0;
	friend class Game;
	friend class TrafficLight;
	friend class Player;
};
#endif // !_OBJECT
