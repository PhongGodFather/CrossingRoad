#pragma once
#ifndef _OBJECT
#define _OBJECT_
#include "Animation.h"

enum MovingDir { left_, right_, up_, down_, idle_ }; // for moving I think :3
class Object : public Position
{
protected:
	Animation anim;
public:
	picture curImg() const { return anim.getCurFrame(); }
	picture preImg() const { return anim.getPreFrame(); }
	void setAnim(const Animation);
	short getColor() { return anim.getCol(); }
	void playAnim();
};
class MovingObject : public Object
{
protected:
	int vel, mov_count, mov_timer;
	MovingDir direction;
public:
	bool is_moving;
	MovingObject() 
	{ 
		mov_count = mov_timer = 100; 
		is_moving = true;
	}
	int velocity() { return vel; }
	void setVel(int k) { vel = k; }
	MovingDir getDir() { return direction; }
    virtual void move(MovingDir) = 0;
};
#endif // !_OBJECT
