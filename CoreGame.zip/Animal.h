#pragma once
#ifndef _ANIMAL_
#define _ANIMAL_
#include "MovingObject.h"
class Animal : public MovingObject
{

public:
	Animal()
	{
		vel = 2; // for all animals as default
	}
	virtual string getName() = 0;
	virtual void move(MovingDir) = 0;
};
class Bird : public Animal
{
public:
	Bird(int x_, int y_, MovingDir dir, int vel_);
	void move(MovingDir dir);
	string getName() { return "Bird"; }
};
class Deer : public Animal
{
public:
	Deer(int x_, int y_, MovingDir dir, int vel_);
	void move(MovingDir dir);
	string getName() { return "Deer"; }
};
#endif // !_ANIMAL_
