#pragma once
#ifndef _ANIMAL_
#define _ANIMAL_
#include "Object.h"
class Animal : public MovingObject
{

public:
	Animal()
	{
		vel = 2; // for all animals as default
	}
	virtual string getName() = 0;
	virtual void move(MovingDir) = 0;
};
class Bird : public Animal
{
public:
	Bird(int x_, int y_, MovingDir dir, int vel_)
	{
		anim = (dir == left_) ? deerAnimatorLeft : deerAnimatorRight;
		direction = dir;
		x = x_;
		y = y_;
		vel = vel_;
	}
	void move(MovingDir dir)
	{
		if (!is_moving)
			return;
		if (mov_count == 0)
		{
			mov_count = mov_timer;
			if (dir == left_) x -= vel;
			else if (dir == right_) x += vel;
			else if (dir == up_) y -= vel;
			else if (dir == down_) y += vel;
		}
		else
			mov_count--;
	}
	string getName() { return "Bird"; }
};
class Deer : public Animal
{
public:
	Deer(int x_, int y_, MovingDir dir, int vel_)
	{
		anim = (dir == left_) ? deerAnimatorLeft : deerAnimatorRight;
		direction = dir;
		x = x_;
		y = y_;
		vel = vel_; // for car only
	}
	void move(MovingDir dir)
	{
		if (!is_moving)
			return;
		if (mov_count == 0)
		{
			mov_count = mov_timer;
			if (dir == left_) x -= vel;
			else if (dir == right_) x += vel;
			else if (dir == up_) y -= vel;
			else if (dir == down_) y += vel;
		}
		else
			mov_count--;
	}
	string getName() { return "Deer"; }
};
#endif // !_ANIMAL_
