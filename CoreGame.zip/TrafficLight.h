#pragma once
#ifndef _TRAFFIC_LIGHT
#define _TRAFFIC_LIGHT
#include "Object.h"
class TrafficLight : public Position
{
	int count, time_red, time_green;
	bool isRed, isGreen;
public:
	TrafficLight(int PosX, int PosY, int timer_red, int timer_green, bool isRed_ = false, int curTime = 0);
	bool isStop() { return (isRed); }
	bool sameLine(const MovingObject* temp);
	void run();
	string getName() { return "lights"; }
	int getGreenTime() { return time_green; }
	int getRedTime() { return time_red; }
	int curTime() { return count; }
};
#endif // !_TRAFFIC_LIGHT