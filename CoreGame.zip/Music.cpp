#include "Music.h"
void playTheme()
{
	mciSendString(LPTSTR("open \"Music/BlueDream.mp3\" type mpegvideo alias background"), NULL, 0, NULL);
	mciSendString(LPTSTR("play background repeat"), NULL, 0, NULL);
}
void playKeyBoardSound()
{
	mciSendString(LPTSTR("open \"Music/beep.mp3\" type mpegvideo alias keyboard"), NULL, 0, NULL);
	mciSendStringA(LPTSTR("play keyboard from 10"), NULL, 0, NULL);
}
void playHitSound()
{
	mciSendString(LPTSTR("open \"Music/HitSound.mp3\" type mpegvideo alias hitSound"), NULL, 0, NULL);
	mciSendStringA(LPTSTR("play hitSound from 200"), NULL, 0, NULL);
}
void playSaveSound()
{
	mciSendString(LPTSTR("open \"Music/SaveSound.mp3\" type mpegvideo alias saveSound"), NULL, 0, NULL);
	mciSendStringA(LPTSTR("play saveSound from 0"), NULL, 0, NULL);
}
void pause() { mciSendString(LPTSTR("pause background"), NULL, 0, NULL); }
void close() { mciSendString(LPTSTR("close background"), NULL, 0, NULL); }
void newPlay()
{
	close();
	mciSendString(LPTSTR("open \"Music/BlueDream.mp3\" type mpegvideo alias background"), NULL, 0, NULL);
	playTheme();
}