﻿#pragma once
#ifndef _GAME_
#define _GAME_
#include <iostream>
#include "Music.h"
#include <fstream>
#include "Console.h"
#include "Player.h"
#include "TrafficLight.h"
#include "Vehicle.h"
#include "Animal.h"
using namespace std;
enum GameState { mainMenu, playMenu, optionMenu, newGame, loadGame, playGame, pauseMenu, credits, exitGame, editSave, win, lose };
class Game : private MyConsole
{
	short bgColor;
	GameState state;
	vector<string> saveFile;
	Player* player;

	vector<TrafficLight*> lights;
	vector<MovingObject*> obstacleList;
public:
	Game();
	Game(int width_, int height_, int fontSize, short color = COLOUR::BG_WHITE);
	void Start(); // main thread - back end thread
	void readSaveFile();
	void drawBorder();

	void drawGame();
	void drawNewGame();
	void drawMenu();
	void drawMenuPlay();
	void drawMenuOption();
	void drawMenuCredit();
	void drawLoadMenu();
	void drawEditSave();
	void drawPauseMenu();

	bool updatePosPlayer(char);
	void updatePosObject(); // for both vehicle and animal to make a move

	void drawPlayer();
	void drawObject();
	void drawGameWin();
	void drawGameDead();

	bool validMove(picture ,int, int, int, MovingDir);
	void CreatePlayer() 
	{ 
		player = new Player(); 
		player->x = (getWidth() - 30) / 2 - player->curImg().getWidth();
		player->y = getHeight() - player->curImg().getHeight() - 1;
	}
	void LoadPlayer(int x, int y, int health, int level)  {  player = new Player(x, y, health, level);  }
	void loadLevel(int level);
	~Game();
};
#endif // !_GAME_