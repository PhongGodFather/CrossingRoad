﻿#include "Console.h"
MyConsole::MyConsole()
{
	ConOut = GetStdHandle(STD_OUTPUT_HANDLE);
	ConIn = GetStdHandle(STD_INPUT_HANDLE);
}
MyConsole::~MyConsole()
{
	delete[] screenBuffer;
	screenBuffer = nullptr;
}
void MyConsole::noCursor()
{
	CONSOLE_CURSOR_INFO Info;
	Info.bVisible = FALSE;
	Info.dwSize = 20;
	SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &Info);
}
void MyConsole::BuildConsole(int width_, int height_, int fontSize, short color = COLOUR::BG_WHITE) // create and construct
{
	ConOut = GetStdHandle(STD_OUTPUT_HANDLE);
	ConIn = GetStdHandle(STD_INPUT_HANDLE);
	ScreenWidth = width_;
	ScreenHeight = height_;

	Window = { 0, 0, (short)(ScreenWidth), (short)(ScreenHeight - 1) };
	SetConsoleWindowInfo(ConOut, TRUE, &Window);

	CONSOLE_FONT_INFOEX cfi;
	cfi.cbSize = sizeof(cfi);
	cfi.nFont = 0;
	cfi.dwFontSize.X = 0;
	cfi.dwFontSize.Y = fontSize;
	cfi.FontFamily = FF_DONTCARE;
	cfi.FontWeight = FW_NORMAL;
	wcscpy_s(cfi.FaceName, L"Consolas");
	SetCurrentConsoleFontEx(ConOut, false, &cfi);

	SetConsoleWindowInfo(ConOut, TRUE, &Window);

	COORD screen_init = { short(ScreenWidth), short(ScreenHeight) };
	SetConsoleScreenBufferSize(ConOut, screen_init);
	SetConsoleActiveScreenBuffer(ConOut);
	ShowWindow(GetConsoleWindow(), SW_MAXIMIZE); // for full screen;

	CONSOLE_SCREEN_BUFFER_INFOEX sbInfoEx;
	sbInfoEx.cbSize = sizeof(CONSOLE_SCREEN_BUFFER_INFOEX);
	GetConsoleScreenBufferInfoEx(ConOut, &sbInfoEx);
	sbInfoEx.dwSize.X = ScreenWidth;
	sbInfoEx.dwSize.Y = ScreenHeight;
	sbInfoEx.srWindow = { 0, 0, (short)ScreenWidth, (short)ScreenHeight };
	sbInfoEx.dwMaximumWindowSize = { (short)ScreenWidth, (short)ScreenHeight };
	SetConsoleScreenBufferInfoEx(ConOut, &sbInfoEx);

	DWORD mode;
	GetConsoleMode(ConOut, &mode);
	mode &= ~ENABLE_WRAP_AT_EOL_OUTPUT;
	SetConsoleMode(ConOut, mode);

	SetConsoleMode(ConIn, ENABLE_EXTENDED_FLAGS | ENABLE_WINDOW_INPUT | ENABLE_MOUSE_INPUT);
	screenBuffer = new CHAR_INFO[ScreenWidth * ScreenHeight];
	noCursor();

	// apply fix window, with no minimize window allowed, no THICK_FRAME too
	HWND consoleWindow = GetConsoleWindow();
	LONG style = GetWindowLong(consoleWindow, GWL_STYLE);
	style = style & ~(WS_MAXIMIZEBOX);
	SetWindowLong(consoleWindow, GWL_STYLE, style);
}
void MyConsole::addChar(int x, int y, wchar_t k, short col)
{
	if (x >= 0 && x < getWidth() && y >= 0 && y < getHeight())
	{
		screenBuffer[x + y * getWidth()].Char.UnicodeChar = k;
		screenBuffer[x + y * getWidth()].Attributes = col;
	}
}
void MyConsole::validate(int &x, int &y)
{
	if (x < 0) x = 0;
	if (x >= getWidth()) x = getWidth();
	if (y < 0) y = 0;
	if (y >= getHeight()) y = getHeight();
}
void MyConsole::FillArea(int x, int y, wchar_t k, int width, int height, short col)
{
	validate(x, y);
	validate(width, height);
	for (int y_ = 0; y_ < height; y_++)
		for (int x_ = 0; x_ < width; x_++)
			addChar(x + x_,y + y_, k, col);
}
void MyConsole::drawConsole() 
{ 
	WriteConsoleOutputW(ConOut, screenBuffer, { short(ScreenWidth), short(ScreenHeight) }, { 0, 0 }, &Window); 
}
void MyConsole::drawPicture(int x, int y, const picture k, short color)
{
	for (int i = 0; i < k.getHeight(); i++)
		drawString(x, y + i, k.getImg()[i], color);
}
void MyConsole::drawButton(int x, int y, wstring text, short color)
{
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < text.size() + 4; j++)
		{
			if (j == 0 && i == 0) // left top corner
				addChar(x + j, y + i, L'┏', color);
			else if (j == text.size() + 3 && i == 0) // right top corner
				addChar(x + j, y + i, L'┓', color);
			else if (j == 0 && i == 2) // left low corner
				addChar(x + j, y + i, L'┗', color);
			else if (j == text.size() + 3 && i == 2) // right low corner
				addChar(x + j, y + i, L'┛', color);
			else if (j == 0 || j == text.size() + 3)
				addChar(x + j, y + i, L'┃', color);
			else if (i == 0 || i == 2)
				addChar(x + j, y + i, L'━', color);
		}
	}
	drawString(x + 2, y + 1, text, color);
}
void MyConsole::drawBox(int x, int y, int width, int height, short color)
{
	for (int i = 0; i < height; i++)
	{
		for (int j = 0; j < width; j++)
		{
			if (j == 0 && i == 0) // left top corner
				addChar(x + j, y + i, L'┏', color);
			else if (j == width - 1 && i == 0) // right top corner
				addChar(x + j, y + i, L'┓', color);
			else if (j == 0 && i == height - 1) // left low corner
				addChar(x + j, y + i, L'┗', color);
			else if (j == width - 1 && i == height - 1) // right low corner
				addChar(x + j, y + i, L'┛', color);
			else if (j == 0 || j == width - 1)
				addChar(x + j, y + i, L'┃', color);
			else if (i == 0 || i == height - 1)
				addChar(x + j, y + i, L'━', color);
		}
	}
}
void MyConsole::drawString(int x, int y, wstring k, short color)
{
	for (int i = 0; i < k.size(); i++)
	{
		screenBuffer[x + i + y * ScreenWidth].Char.UnicodeChar = k[i];
		screenBuffer[x + i + y * ScreenWidth].Attributes = color;
	}
}
void MyConsole::drawStringC(int x, int y, string k, short color)
{
	for (int i = 0; i < k.size(); i++)
	{
		screenBuffer[x + i + y * ScreenWidth].Char.UnicodeChar = k[i];
		screenBuffer[x + i + y * ScreenWidth].Attributes = color;
	}
}
void MyConsole::setPosColor(int x, int y, short col)
{
	screenBuffer[x + y * getWidth()].Attributes = col;
}
void MyConsole::clearConsole(short color)
{
	for (int i = 0; i < getWidth() * getHeight(); i++)
	{
		screenBuffer[i].Char.UnicodeChar = ' ';
		screenBuffer[i].Attributes = color;
	}
}