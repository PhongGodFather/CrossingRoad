#include "Vehicle.h"
// there will be linker error if I dont create function definition outside of the header file
Car::Car(int x_, int y_, MovingDir dir, int vel_)
{
	anim = (dir == left_) ? carAnimatorLeft : carAnimatorRight;
	direction = dir;
	x = x_;
	y = y_;
	vel = vel_; // for car only
}
void Car::move(MovingDir dir)
{
	if (!is_moving)
		return;
	if (mov_count == 0)
	{
		mov_count = mov_timer;
		if (dir == left_) x -= vel;
		else if (dir == right_) x += vel;
		else if (dir == up_) y -= vel;
		else if (dir == down_) y += vel;
	}
	else
		mov_count--;
	// playAnim();
}
Truck::Truck(int x_, int y_, MovingDir dir, int vel_)
{
	anim = (dir == left_) ? truckAnimatorLeft : truckAnimatorRight;
	direction = dir;
	x = x_;
	y = y_;
	vel = vel_;
}
void Truck::move(MovingDir dir)
{
	if (!is_moving)
		return;
	if (mov_count == 0)
	{
		mov_count = mov_timer;
		if (dir == left_) x -= vel;
		else if (dir == right_) x += vel;
		else if (dir == up_) y -= vel;
		else if (dir == down_) y += vel;
	}
	else
		mov_count--;
	// playAnim();
}