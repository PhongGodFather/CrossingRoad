#include "Vehicle.h"
// there will be linker error if I dont create function definition outside of the header file
Car::Car(int x_, int y_, MovingDir dir, int vel_)
{
	anim = (dir == left_) ? carAnimatorLeft : carAnimatorRight;
	direction = dir;
	x = x_;
	y = y_;
	vel = vel_; // for car only
}
Truck::Truck(int x_, int y_, MovingDir dir, int vel_)
{
	anim = (dir == left_) ? truckAnimatorLeft : truckAnimatorRight;
	direction = dir;
	x = x_;
	y = y_;
	vel = vel_;
}