#include "Vehicle.h"
// there will be linker error if I dont create function definition outside of the header file