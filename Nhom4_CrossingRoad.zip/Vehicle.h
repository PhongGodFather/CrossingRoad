#pragma once
#ifndef _VEHICLE_
#define _VEHICLE_
#include "MovingObject.h"
class Vehicle : public MovingObject
{
public:
	Vehicle()
	{
		vel = 1; // for all vehicles as default
	}
	virtual string getName() = 0;
};
class Car : public Vehicle
{
public:
	Car(int x_, int y_, MovingDir dir, int vel_);
	string getName() { return "Car"; }
};
class Truck : public Vehicle
{
public:
	Truck(int x_, int y_, MovingDir dir, int vel_);
	string getName() { return "Truck"; }
};
#endif // !_VEHICLE_