#include "MovingObject.h"
MovingObject::MovingObject()
{
	mov_count = Sleep_time; // this is my sleep time
	is_moving = true;
}
void MovingObject::setAnim(const Animation animation)
{
	anim = animation;
}
void MovingObject::playAnim()
{
	anim.play();
}
void MovingObject::move(MovingDir dir)
{
	playAnim();
	if (!is_moving)
		return;
	if (mov_count == 0)
	{
		mov_count = Sleep_time;
		if (dir == left_) x -= vel;
		else if (dir == right_) x += vel;
		else if (dir == up_) y -= vel;
		else if (dir == down_) y += vel;
	}
	else
		mov_count--;
}