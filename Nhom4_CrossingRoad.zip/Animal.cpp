#include "Animal.h"
Bird::Bird(int x_, int y_, MovingDir dir, int vel_)
{
	anim = (dir == left_) ? duckAnimatorLeft : duckAnimatorRight;
	direction = dir;
	x = x_;
	y = y_;
	vel = vel_;
}
Deer::Deer(int x_, int y_, MovingDir dir, int vel_)
{
	anim = (dir == left_) ? deerAnimatorLeft : deerAnimatorRight;
	direction = dir;
	x = x_;
	y = y_;
	vel = vel_;
}