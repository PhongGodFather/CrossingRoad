#pragma once
#ifndef _TRAFFIC_LIGHT
#define _TRAFFIC_LIGHT
#include "MovingObject.h"
class TrafficLight
{
	int x, y;
	int count, time_red, time_green;
	bool isRed;
public:
	TrafficLight(){}
	TrafficLight(int PosX, int PosY, int timer_red, int timer_green, bool isRed_ = false, int curTime = 0);
	bool isStop() { return (isRed); }
	bool sameLine(const MovingObject* temp);
	void run();
	string getName() { return "lights"; }
	int getGreenTime() { return time_green; }
	int getRedTime() { return time_red; }
	int curTime() { return count; }
	friend class Game;
};
#endif // !_TRAFFIC_LIGHT