#pragma once
#ifndef _MUSIC_
#define _MUSIC_
#include <iostream>
#include <Windows.h>
#pragma comment(lib, "Winmm.lib")
using namespace std;
void playTheme();
void playKeyBoardSound();
void playHitSound();
void playSaveSound();
void pause();
void close();
void newPlay();
#endif // !_MUSIC_