#pragma once
#ifndef _MOVING_OBJECT_
#define _MOVING_OBJECT_
#include "Animation.h"
const int Sleep_time = 20;
enum MovingDir { left_, right_, up_, down_, idle_ };
class MovingObject
{
protected:
	int x, y;
	Animation anim;
	int vel, mov_count;
	MovingDir direction;
	bool is_moving;
public:
	MovingObject();
	picture curImg() const { return anim.getCurFrame(); }
	picture preImg() const { return anim.getPreFrame(); }
	void setAnim(const Animation);
	short getColor() { return anim.getCol(); }
	void playAnim();
	int velocity() { return vel; }
	void setVel(int k) { vel = k; }
	MovingDir getDir() { return direction; }
    virtual void move(MovingDir);
	virtual string getName() = 0;
	friend class Game;
	friend class TrafficLight;
	friend class Player;
};
#endif // !_OBJECT
