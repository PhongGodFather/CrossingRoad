﻿#include "Game.h"
thread scene;
bool OnMusic = true;
Game::Game()
{
	bgColor = COLOUR::BG_WHITE;
	BuildConsole(210, 49, 16, COLOUR::BG_WHITE);
	FillArea(0, 0, L' ', ScreenWidth, ScreenHeight, bgColor);
	readSaveFile();
	state = mainMenu;
	scene = thread(&Game::drawMenu, this);
	playTheme();
}
Game::Game(int width_, int height_, int fontSize, short color)
{
	BuildConsole(width_, height_, fontSize, color);
	bgColor = color;
	FillArea(0, 0, L' ', ScreenWidth, ScreenHeight, bgColor);
	readSaveFile();
	state = mainMenu;
	scene = thread(&Game::drawMenu, this);
	playTheme();
}
Game::~Game()
{
	fstream file("Saves/savegame.txt", ios::out);
	for (auto i : saveFile)
	{
		// check if the player did save this file, else delete it from the RAM
		fstream file_i("Saves/" + i + ".txt", ios::in);
		if (!file_i.fail())
			file << i << endl;
		file_i.close();
	}
	file.close();

	for (auto i : obstacleList)
		delete i;
	obstacleList.clear();
}
void Game::drawBorder()
{
	// drawing border, first frame to create border
	short borderColor = bgColor | FG_DARK_GREEN;
	for (int y = 0; y < ScreenHeight; y++)
	{
		for (int x = 0; x < ScreenWidth; x++)
		{
			if (x == 0 && y == 0) // left top corner
				addChar(x, y, L'╔', borderColor);
			else if (x == ScreenWidth - 1 && y == 0) // right top corner
				addChar(x, y, L'╗', borderColor);
			else if (x == 0 && y == ScreenHeight - 1) // left low corner
				addChar(x, y, L'╚', borderColor);
			else if (x == ScreenWidth - 1 && y == ScreenHeight - 1) // right low corner
				addChar(x, y, L'╝', borderColor);
			else if (x == 0 || x == ScreenWidth - 1)
				addChar(x, y, L'║', borderColor);
			else if (y == 0 || y == ScreenHeight - 1)
				addChar(x, y, L'═', borderColor);
		}
	}
}
void Game::readSaveFile()
{
	fstream file("Saves/savegame.txt", ios::in);
	string temp;
	while (!file.eof())
	{
		getline(file, temp, '\n');
		if (temp != "")
		{
			fstream file_i("Saves/" + temp + ".txt", ios::in);
			if (!file_i.fail())
				saveFile.push_back(temp);
			file_i.close();
		}
	}
	file.close();
}
string name = "", curFileName; // for new file
char MOVING;
int counter = 2, index = counter;
int offset_box = 30; // for box covering

void Game::Start()
{
	while (true)
	{
		char key = getch();
		if (state == mainMenu)
		{
			if (key == 'w' && counter > 1)
				counter--;
			if (key == 's' && counter < 4)
				counter++;

			if (key == '\r')
			{
				if (counter == 1)
				{
					state = playMenu;
					scene.join();                                 // shutdown mainMenu thread
					scene = thread(&Game::drawMenuPlay, this); // start the playMenu thread
				}
				if (counter == 2)
				{
					counter = 1;
					state = optionMenu;
					scene.join();                                   // shutdown mainMenu thread
					scene = thread(&Game::drawMenuOption, this); // start the optionMenu thread
				}
				if (counter == 3)
				{
					state = credits;
					scene.join();
					scene = thread(&Game::drawMenuCredit, this);
				}
				if (counter == 4) // exit the game
				{
					state = exitGame;
					scene.join();      // shutdown mainMenu thread
					break;
				}
			}
		}
		else if (state == playMenu)
		{
			if (key == 'w' && counter > 1)
				counter--;
			if (key == 's' && counter < 3)
				counter++;

			if (key == '\r')
			{
				if (counter == 1)
				{
					// shutdown menu thread start game thread
					state = newGame;
					scene.join();
					scene = thread(&Game::drawNewGame, this);
				}
				if (counter == 2)
				{
					state = loadGame;
					scene.join();
					scene = thread(&Game::drawLoadMenu, this);
					counter = 1;
				}
				if (counter == 3)
				{
					state = mainMenu; // back to the main menu thread
					scene.join();
					scene = thread(&Game::drawMenu, this);
				}
			}
		}
		else if (state == optionMenu)
		{
			if (key == 'w' && counter > 1)
				counter--;
			if (key == 's' && counter < 2)
				counter++;
			if (key == '\r')
			{
				if (counter == 1)
				{
					if (OnMusic)
					{
						close();
						OnMusic = false;
					}
					else
					{
						newPlay();
						OnMusic = true;
					}
				}
				else
				{
					state = mainMenu;
					scene.join();
					scene = thread(&Game::drawMenu, this);
				}
			}
		}
		else if (state == loadGame)
		{
			if (key == 'w' && counter > 1)
				counter--;
			if (key == 's' && counter < saveFile.size() + 1)
				counter++;
			if (key == '\r')
			{
				if (counter == 1)
				{
					state = playMenu;
					counter = 2;
					scene.join();
					scene = thread(&Game::drawMenuPlay, this);
				}
				else
				{
					// load data to the player and start the game thread
					// or u can make another Menu list like remove save files, edit save file name
					state = editSave;
					counter = 1;
					scene.join();
					scene = thread(&Game::drawEditSave, this);
				}
			}
		}
		else if (state == editSave)
		{
			if (key == 'w' && counter > 1)
				counter--;
			if (key == 's' && counter < 3)
				counter++;
			if (key == '\r')
			{
				if (counter == 1)
				{
					state = loadGame;
					counter = index + 2;
					scene.join();
					scene = thread(&Game::drawLoadMenu, this);
				}
				else if (counter == 2)
				{
					// delete the save file first
					string _name = "Saves/" + saveFile[index] + ".txt";
					int k = _name.length();
					char* Fname = new char[k + 1];
					strcpy(Fname, _name.c_str());
					remove(Fname);
					delete[] Fname;
					// pop it from the RAM
					saveFile.erase(saveFile.begin() + index);
					state = loadGame;
					counter = index + 1;
					scene.join();
					scene = thread(&Game::drawLoadMenu, this);
				}
				else if (counter == 3)
				{
					// load data, should have placed inside a function or something
					curFileName = saveFile[index];
					string _name = curFileName + ".txt";
					fstream file("Saves/" + _name, ios::in);
					int _x , _y , health, level;
					file >> _x >> _y >> health >> level;
					LoadPlayer(_x,_y, health, level); // temporary test
					// load game data
					string _type = " ";
					int _velocity, _dir;

					while (!file.eof())
					{
						file >> _type;
						if (_type == "Car" || _type == "Truck" || _type == "Deer" || _type == "Bird")
						{
							file >> _x >> _y >> _dir >> _velocity;
							if (_type == "Car")
							{
								if (_dir == 1)
									obstacleList.push_back(new Car(_x, _y, right_, _velocity));
								else
									obstacleList.push_back(new Car(_x, _y, left_, _velocity));
							}
							else if (_type == "Truck")
							{
								if (_dir == 1)
									obstacleList.push_back(new Truck(_x, _y, right_, _velocity));
								else
									obstacleList.push_back(new Truck(_x, _y, left_, _velocity));
							}
							else if (_type == "Deer")
							{
								if (_dir == 1)
									obstacleList.push_back(new Deer(_x, _y, right_, _velocity));
								else
									obstacleList.push_back(new Deer(_x, _y, left_, _velocity));
							}
							else if (_type == "Bird")
							{
								if (_dir == 1)
									obstacleList.push_back(new Bird(_x, _y, right_, _velocity));
								else
									obstacleList.push_back(new Bird(_x, _y, left_, _velocity));
							}
						}
						else if (_type == "lights")
						{
							int tR = 0, tG = 0, _stop = 0, cT = 0;
							file >> _x >> _y >> tR >> tG >> _stop >> cT;
							lights.push_back(new TrafficLight(_x, _y, tR, tG, _stop, cT));
						}
					}
					lights.pop_back();
					file.close();

					// start the game
					state = playGame;
					scene.join();
					scene = thread(&Game::drawGame, this);
				}
			}
		}
		else if (state == credits)
		{
			if (key == '\r')
			{
				state = mainMenu;
				scene.join();
				scene = thread(&Game::drawMenu, this);
			}
		}
		else if (state == newGame)
		{
			if (key == '\r' && !name.empty())
			{
				// start as default of level 1
				for (auto i : obstacleList)
					delete i;
				obstacleList.clear();
				loadLevel(1);

				state = playGame;
				scene.join();
				scene = thread(&Game::drawGame, this);
				saveFile.push_back(name);
				curFileName = name;
				index = saveFile.size() - 1;
				CreatePlayer();
				name = "";
			}
			else if (key != '\b' && name.length() < 20)
				name += key;
			else if (!name.empty())
				name.pop_back();
		}
		else if (state == pauseMenu)
		{
			if (key == 'w' && counter > 1)
				counter--;
			if (key == 's' && counter < 3)
				counter++;

			if (key == '\r')
			{
				if (counter == 1)
				{
					// shutdown menu thread start game thread
					state = playGame;
					scene.join();
					scene = thread(&Game::drawGame, this);
				}
				if (counter == 2)
				{
					fstream file("Saves/savegame.txt", ios::app);
					file << curFileName;
					file.close();
					file.open("Saves/" + curFileName + ".txt", ios::out);
					file << player->x << " " << player->y << " " << player->getHealth() << " " << player->getLevel() << endl;
					for (auto i : obstacleList)
						file << i->getName() << " " << i->x << " " << i->y << " " << i->getDir() << " " << i->velocity() << endl;
					for (auto i : lights)
						file << i->getName() << " " << i->x << " " << i->y << " " << i->getRedTime() << " " << i->getGreenTime() << " " << i->isStop() << " " << i->curTime() << endl;
					file.close();

					// announcement
					drawButton(ScreenWidth / 2, title.getHeight() + 7, L"ĐÃ LƯU FILE GAME", bgColor | FG_RED);
					drawConsole();
					playSaveSound();
					Sleep(1000);
					FillArea(ScreenWidth / 2 - 1, title.getHeight() + 7, L' ', 21, 3, bgColor);
					// saveFile.push_back(name);
				}
				if (counter == 3)
				{
					state = mainMenu; // back to the main menu thread
					scene.join();
					scene = thread(&Game::drawMenu, this);
					// pop the unsaved file out
					fstream file_i("Saves/" + curFileName + ".txt", ios::in);
					if (file_i.fail())
						saveFile.erase(saveFile.begin() + index);
					file_i.close();

					// clear the dumb shit
					for (auto i : obstacleList)
						delete i;
					obstacleList.clear();
					for (auto i : lights)
						delete i;
					lights.clear();
				}
			}
		}
		else if (state == playGame) // the main game back end system
		{
			// load default level if it be empty
			if (obstacleList.empty() && lights.empty())
				loadLevel(player->getLevel());
			
			MOVING = toupper(key);
			if (key == 27)
			{
				// do the pause menu
				state = pauseMenu;
				scene.join();
				scene = thread(&Game::drawPauseMenu, this);
				counter = 1;
			}
			if (player->isDead())
			{
				state = lose;
				scene.join();
				scene = thread(&Game::drawGameDead, this);
			}
			if (MOVING == 'W' && player->y - player->velocity() <= 0)
			{
				if (player->isFinish() && !player->isDead())
				{
					state = win;
					scene.join();
					scene = thread(&Game::drawGameWin, this);
				}
			}
		}
		else if (state == win || state == lose)
		{
			if (key == '\r')
			{
				fstream file_i("Saves/" + curFileName + ".txt", ios::in);
				if (file_i.fail())
					saveFile.erase(saveFile.begin() + index);
				file_i.close();

				state = mainMenu;
				scene.join();
				scene = thread(&Game::drawMenu, this);
				counter = 1;
			}
		}
	}
}
void Game::drawMenu()
{
	short hoverCol = bgColor | FG_RED, defaultCol = bgColor | FG_CYAN;
	Animation test = deerAnimatorRight;
	Animation car = carAnimatorRight;
	int xTest = 20, yTest = 34;
	int movCount = Sleep_time;

	while (state == mainMenu)
	{
		drawBorder();
		drawPicture(ScreenWidth / 2 - title.getWidth() / 1.5, 1, title, bgColor | FG_DARK_MAGENTA);
		car.play();
		drawPicture(50, 20, car.getCurFrame(), bgColor | FG_DARK_RED);
		drawPicture(30, 15, snowFlake, bgColor | FG_BLUE);
		drawPicture(110, 17, christmasTree, bgColor | FG_DARK_GREEN);
		drawPicture(113, 16, star, bgColor | FG_DARK_YELLOW);
		drawPicture(70, 38, snow, bgColor | FG_DARK_BLUE);
		drawPicture(125, 12, bell, bgColor | FG_DARK_YELLOW);
		drawBox(ScreenWidth / 2 - 27, title.getHeight() + 3, 17, 14, bgColor | FG_BLUE);
		drawButton(70, 30, L"Nhấn W,A,S,D để di chuyển và ENTER để chọn lựa chọn", bgColor | FG_DARK_BLUE);
		if (counter == 1)
			drawButton(ScreenWidth / 2 - 25, title.getHeight() + 4, L"PLAY GAME", hoverCol);
		else
			drawButton(ScreenWidth / 2 - 25, title.getHeight() + 4, L"PLAY GAME", defaultCol);

		if (counter == 2)
			drawButton(ScreenWidth / 2 - 24, title.getHeight() + 7, L"OPTION", hoverCol);
		else
			drawButton(ScreenWidth / 2 - 24, title.getHeight() + 7, L"OPTION", defaultCol);

		if (counter == 3)
			drawButton(ScreenWidth / 2 - 24, title.getHeight() + 10, L"CREDITS", hoverCol);
		else
			drawButton(ScreenWidth / 2 - 24, title.getHeight() + 10, L"CREDITS", defaultCol);

		if (counter == 4)
			drawButton(ScreenWidth / 2 - 25, title.getHeight() + 13, L"QUIT GAME", hoverCol);
		else
			drawButton(ScreenWidth / 2 - 25, title.getHeight() + 13, L"QUIT GAME", defaultCol);
		if (movCount == 0) {
			movCount = Sleep_time;
			xTest++;
			if (xTest + test.getCurFrame().getWidth() >= ScreenWidth) {
				xTest = 20;
			}
		}
		else
			movCount--;
		test.play();
		drawPicture(xTest, yTest, test.getCurFrame(), bgColor | FG_DARK_RED);
		drawConsole(); // remember this
		clearConsole();
	}
	clearConsole();
}
void Game::drawMenuOption()
{
	Animation man = manAnimator;
	Animation test = duckAnimatorLeft;
	int xTest = 150, yTest = 30;
	int movCount = Sleep_time;

	short hoverCol = bgColor | FG_RED, defaultCol = bgColor | FG_CYAN;
	while (state == optionMenu)
	{
		drawBorder();
		drawPicture(ScreenWidth / 2 - title.getWidth() / 1.5, 1, title, bgColor | FG_DARK_MAGENTA);
		man.play();
		drawPicture(50, 20, man.getCurFrame(), bgColor | FG_RED); // bruh
		drawPicture(30, 15, snowFlake, bgColor | FG_BLUE);
		drawPicture(110, 17, christmasTree, bgColor | FG_DARK_GREEN);
		drawPicture(113, 16, star, bgColor | FG_DARK_YELLOW);
		drawPicture(70, 38, snow, bgColor | FG_DARK_BLUE);
		drawPicture(125, 12, bell, bgColor | FG_DARK_YELLOW);
		drawBox(ScreenWidth / 2 - 27, title.getHeight() + 3, 20, 8, bgColor | FG_BLUE);
		wstring text = (OnMusic) ? L"MUSIC: ON " : L"MUSIC: OFF";
		if (counter == 1)
			drawButton(ScreenWidth / 2 - 24, title.getHeight() + 4, text, hoverCol);
		else
			drawButton(ScreenWidth / 2 - 24, title.getHeight() + 4, text, defaultCol);

		if (counter == 2)
			drawButton(ScreenWidth / 2 - 25, title.getHeight() + 7, L"BACK TO MENU", hoverCol);
		else
			drawButton(ScreenWidth / 2 - 25, title.getHeight() + 7, L"BACK TO MENU", defaultCol);
		if (movCount == 0) {
			movCount = Sleep_time;
			xTest--;
			if (xTest <= 0) {
				xTest = ScreenWidth - test.getCurFrame().getWidth();
			}
		}
		else
			movCount--;
		test.play();
		drawPicture(xTest, yTest, test.getCurFrame(), bgColor | FG_DARK_RED);
		drawConsole(); // remember this
		clearConsole();
	}
	clearConsole();
}
void Game::drawMenuCredit()
{
	short hoverCol = bgColor | FG_RED, defaultCol = bgColor | FG_DARK_YELLOW;
	Animation test = manAnimator;
	int xTest = 20, yTest = 28;
	int movCount = Sleep_time;

	const picture temp(vector<wstring>{
		L"21127668 - ĐINH QUANG PHONG",
			L"21127456 - VÕ CAO TRÍ",
			L"21127730 - HOÀNG LÊ CÁT THANH",
			L"21127149 - HUỲNH MINH QUANG"
	});
	while (state == credits)
	{
		drawBorder();
		drawPicture(ScreenWidth / 2 - title.getWidth() / 1.5, 1, title, bgColor | FG_DARK_MAGENTA);
		drawBox(ScreenWidth / 2 - 27, title.getHeight() + 3, temp.getWidth() + 4, temp.getHeight() + 6, bgColor | FG_BLUE);
		drawPicture(30, 15, snowFlake, bgColor | FG_BLUE);
		drawPicture(115, 17, christmasTree, bgColor | FG_DARK_GREEN);
		drawPicture(118, 16, star, bgColor | FG_DARK_YELLOW);
		drawPicture(70, 38, snow, bgColor | FG_DARK_BLUE);
		drawPicture(125, 12, bell, bgColor | FG_DARK_YELLOW);
		drawButton(ScreenWidth / 2 - 25, title.getHeight() + 4, L"BACK TO MENU", hoverCol);
		drawPicture(ScreenWidth / 2 - 25, title.getHeight() + 8, temp, defaultCol);
		if (movCount == 0) {
			movCount = Sleep_time;
			xTest++;
			if (xTest + test.getCurFrame().getWidth() >= ScreenWidth) {
				xTest = 20;
			}
		}
		else
			movCount--;
		test.play();
		drawPicture(xTest, yTest, test.getCurFrame(), bgColor | FG_DARK_RED);
		drawConsole(); // remember this
		clearConsole();
	}
	clearConsole();
}
void Game::drawMenuPlay()
{
	short hoverCol = bgColor | FG_RED, defaultCol = bgColor | FG_CYAN;
	Animation test = carAnimatorRight;
	int xTest = 20, yTest = 34;
	int movCount = Sleep_time;

	while (state == playMenu)
	{
		drawBorder();
		drawPicture(ScreenWidth / 2 - title.getWidth() / 1.5, 1, title, bgColor | FG_DARK_MAGENTA);
		drawPicture(30, 15, snowFlake, bgColor | FG_BLUE);
		drawPicture(110, 17, christmasTree, bgColor | FG_DARK_GREEN);
		drawPicture(113, 16, star, bgColor | FG_DARK_YELLOW);
		drawPicture(70, 38, snow, bgColor | FG_DARK_BLUE);
		drawPicture(125, 12, bell, bgColor | FG_DARK_YELLOW);
		drawBox(ScreenWidth / 2 - 27, title.getHeight() + 3, 20, 11, bgColor | FG_BLUE);
		if (counter == 1)
			drawButton(ScreenWidth / 2 - 24, title.getHeight() + 4, L"NEW GAME", hoverCol);
		else
			drawButton(ScreenWidth / 2 - 24, title.getHeight() + 4, L"NEW GAME", defaultCol);

		if (counter == 2)
			drawButton(ScreenWidth / 2 - 24, title.getHeight() + 7, L"LOAD GAME", hoverCol);
		else
			drawButton(ScreenWidth / 2 - 24, title.getHeight() + 7, L"LOAD GAME", defaultCol);

		if (counter == 3)
			drawButton(ScreenWidth / 2 - 25, title.getHeight() + 10, L"BACK TO MENU", hoverCol);
		else
			drawButton(ScreenWidth / 2 - 25, title.getHeight() + 10, L"BACK TO MENU", defaultCol);
		if (movCount == 0) {
			movCount = Sleep_time;
			xTest++;
			if (xTest + test.getCurFrame().getWidth() >= ScreenWidth) {
				xTest = 20;
			}
		}
		else
			movCount--;
		test.play();
		drawPicture(xTest, yTest, test.getCurFrame(), bgColor | FG_DARK_RED);

		drawConsole(); // remember this
		clearConsole();
	}
	clearConsole();
}
void Game::drawLoadMenu()
{
	drawBorder();
	drawPicture(ScreenWidth / 2 - title.getWidth() / 1.5, 1, title, bgColor | FG_DARK_MAGENTA);
	drawPicture(50, 20, car1, bgColor | FG_RED); // bruh
	int max = 0;
	for (auto i : saveFile)
		if (i.length() > max)
			max = i.length();
	if (max < 12) // the back to menu size
		max = 13;
	drawBox(ScreenWidth / 2 - 27, title.getHeight() + 3, max * 2 - max / 3, saveFile.size() * 3 + 5, bgColor | FG_BLUE);
	short hoverCol = bgColor | FG_RED, defaultCol = bgColor | FG_CYAN;

	drawButton(ScreenWidth / 2 - 52, title.getHeight() + 4, L"CHOOSE A SAVE GAME >", bgColor | FG_DARK_CYAN);
	while (state == loadGame)
	{
		if (counter == 1)
			drawButton(ScreenWidth / 2 - 24, title.getHeight() + 4, L"BACK TO MENU", hoverCol);
		else
			drawButton(ScreenWidth / 2 - 24, title.getHeight() + 4, L"BACK TO MENU", defaultCol);

		for (int i = 0; i < saveFile.size(); i++)
		{
			wstring temp(saveFile[i].length(), L' ');
			copy(saveFile[i].begin(), saveFile[i].end(), temp.begin());
			if (counter == i + 2)
			{
				drawButton(ScreenWidth / 2 - 24, title.getHeight() + 7 + i * 3, temp, hoverCol);
				index = i;
			}
			else
				drawButton(ScreenWidth / 2 - 24, title.getHeight() + 7 + i * 3, temp, defaultCol);
		}

		drawConsole(); // remember this
	}
	clearConsole();
}
void Game::drawEditSave()
{
	drawBorder();
	drawPicture(ScreenWidth / 2 - title.getWidth() / 1.5, 1, title, bgColor | FG_DARK_MAGENTA);
	drawPicture(50, 20, car1, bgColor | FG_RED); // bruh
	short hoverCol = bgColor | FG_RED, defaultCol = bgColor | FG_CYAN;
	int max = 0;
	for (auto i : saveFile)
		if (i.length() > max)
			max = i.length();
	if (max < 12)
		max = 13;
	drawBox(ScreenWidth / 2 - 27, title.getHeight() + 3, max * 2 - max / 3, saveFile.size() * 3 + 5, bgColor | FG_BLUE);
	drawButton(ScreenWidth / 2 - 52, title.getHeight() + 4, L"CHOOSE A SAVE GAME >", bgColor | FG_DARK_CYAN);
	while (state == editSave)
	{
		drawButton(ScreenWidth / 2 - 24, title.getHeight() + 4, L"BACK TO MENU", defaultCol);
		for (int i = 0; i < saveFile.size(); i++)
		{
			wstring temp(saveFile[i].length(), L' ');
			copy(saveFile[i].begin(), saveFile[i].end(), temp.begin());
			if (i == index)
				drawButton(ScreenWidth / 2 - 24, title.getHeight() + 7 + i * 3, temp, hoverCol);
			else
				drawButton(ScreenWidth / 2 - 24, title.getHeight() + 7 + i * 3, temp, defaultCol);
		}
		if (counter == 1)
			drawButton(ScreenWidth / 2 + max - 10, title.getHeight() + 7 + index * 3, L"BACK", hoverCol);
		else
			drawButton(ScreenWidth / 2 + max - 10, title.getHeight() + 7 + index * 3, L"BACK", defaultCol);
		if (counter == 2)
			drawButton(ScreenWidth / 2 + max - 10, title.getHeight() + 10 + index * 3, L"DELETE", hoverCol);
		else
			drawButton(ScreenWidth / 2 + max - 10, title.getHeight() + 10 + index * 3, L"DELETE", defaultCol);
		if (counter == 3)
			drawButton(ScreenWidth / 2 + max - 10, title.getHeight() + 13 + index * 3, L"PLAY", hoverCol);
		else
			drawButton(ScreenWidth / 2 + max - 10, title.getHeight() + 13 + index * 3, L"PLAY", defaultCol);
		drawConsole(); // remember this
	}
	clearConsole();
}
void Game::drawNewGame()
{
	Animation test = truckAnimatorLeft;
	Animation bird = duckAnimatorRight;
	int xTest = 100, yTest = 34;
	int movCount = Sleep_time;
	short defaultCol = bgColor | FG_DARK_BLUE;
	while (state == newGame)
	{
		drawBorder();
		drawPicture(ScreenWidth / 2 - title.getWidth() / 1.5, 1, title, bgColor | FG_DARK_MAGENTA);
		bird.play();
		drawPicture(50, 20, bird.getCurFrame(), bgColor | FG_RED); // bruh
		drawPicture(30, 15, snowFlake, bgColor | FG_BLUE);
		drawPicture(110, 17, christmasTree, bgColor | FG_DARK_GREEN);
		drawPicture(113, 16, star, bgColor | FG_DARK_YELLOW);
		drawPicture(70, 38, snow, bgColor | FG_DARK_BLUE);
		drawPicture(125, 12, bell, bgColor | FG_DARK_YELLOW);
		drawString(ScreenWidth / 2 - 23, title.getHeight() + 4, L"ENTER NEW NAME ", defaultCol);
		drawBox(ScreenWidth / 2 - 25, title.getHeight() + 5, 24, 3, defaultCol);
		FillArea(ScreenWidth / 2 - 24, title.getHeight() + 6, L' ', 21, 1, defaultCol);
		drawStringC(ScreenWidth / 2 - 23, title.getHeight() + 6, name, defaultCol);
		if (movCount == 0) {
			movCount = Sleep_time;
			xTest--;
			if (xTest <= 0) {
				xTest = ScreenWidth - test.getCurFrame().getWidth();
			}
		}
		else
			movCount--;
		test.play();
		drawPicture(xTest, yTest, test.getCurFrame(), bgColor | FG_DARK_RED);

		drawConsole(); // remember this
		clearConsole();
	}
	clearConsole();
}
void Game::drawPauseMenu()
{
	drawBorder();
	drawPicture(ScreenWidth / 2 - title.getWidth() / 1.5, 1, title, bgColor | FG_DARK_MAGENTA);
	// drawPicture(50, 20, car1, bgColor | FG_RED); // bruh
	drawBox(ScreenWidth / 2 - 27, title.getHeight() + 3, 20, 11, bgColor | FG_BLUE);

	short hoverCol = bgColor | FG_RED, defaultCol = bgColor | FG_CYAN;
	while (state == pauseMenu)
	{
		if (counter == 1)
			drawButton(ScreenWidth / 2 - 23, title.getHeight() + 4, L"RESUME", hoverCol);
		else
			drawButton(ScreenWidth / 2 - 23, title.getHeight() + 4, L"RESUME", defaultCol);

		if (counter == 2)
			drawButton(ScreenWidth / 2 - 24, title.getHeight() + 7, L"SAVE GAME", hoverCol);
		else
			drawButton(ScreenWidth / 2 - 24, title.getHeight() + 7, L"SAVE GAME", defaultCol);

		if (counter == 3)
			drawButton(ScreenWidth / 2 - 25, title.getHeight() + 10, L"BACK TO MENU", hoverCol);
		else
			drawButton(ScreenWidth / 2 - 25, title.getHeight() + 10, L"BACK TO MENU", defaultCol);

		drawConsole();
	}
	clearConsole();
}

bool Game::validMove(picture img, int x, int y, int vel, MovingDir dir)
{
	if (x - vel < 0 && dir == left_ || x + vel + img.getWidth() >= ScreenWidth - offset_box && dir == right_)
		return false;
	if (y - vel < 0 && dir == up_ || y + img.getHeight() + vel >= ScreenHeight && dir == down_)
		return false;
	return true;
}

bool Game::updatePosPlayer(char key)
{
	if (key == 'D' || key == 'A' || key == 'S' || key == 'W')
		if (OnMusic)
			playKeyBoardSound();
	if (key == 'D' && validMove(player->curImg(), player->x, player->y, player->velocity(), right_))
	{
		player->move(right_);
		FillArea(player->x - player->velocity(), player->y, L' ', player->preImg().getWidth(), player->preImg().getHeight(), bgColor);
	}
	if (key == 'A' && validMove(player->curImg(), player->x, player->y, player->velocity(), left_))
	{
		player->move(left_);
		FillArea(player->x + player->velocity(), player->y, L' ', player->preImg().getWidth(), player->preImg().getHeight(), bgColor);
	}
	if (key == 'W' && player->y - player->velocity() <= 0) // touch the roof. go to next Level
	{
		clearConsole();
		// clear up RAM
		for (auto i : obstacleList)
			delete i;
		obstacleList.clear();
		for (auto i : lights)
			delete i;
		lights.clear();

		if (player->isFinish())
			return false;

		player->y = ScreenHeight - player->curImg().getHeight() - 1;
		player->x = (ScreenWidth - offset_box) / 2 - player->curImg().getWidth();
		player->nextLevel();
		loadLevel(player->getLevel());
		return true;
	}
	if (key == 'W' && validMove(player->curImg(), player->x, player->y, player->velocity(), up_))
	{
		player->move(up_);
		FillArea(player->x, player->y + player->velocity(), L' ', player->preImg().getWidth(), player->preImg().getHeight(), bgColor);
	}
	if (key == 'S' && validMove(player->curImg(), player->x, player->y, player->velocity(), down_))
	{
		player->move(down_);
		FillArea(player->x, player->y - player->velocity(), L' ', player->preImg().getWidth(), player->preImg().getHeight(), bgColor);
	}
	return true;
}
void Game::updatePosObject()
{
	for (auto i : obstacleList)
	{
		if (i == NULL) continue;
		MovingDir direction = i->getDir();
		i->move(direction);
		if (direction == right_)
			FillArea(i->x - i->velocity(), i->y, L' ', i->preImg().getWidth(), i->preImg().getHeight(), bgColor);
		if (direction == left_)
			FillArea(i->x + i->velocity(), i->y, L' ', i->preImg().getWidth(), i->preImg().getHeight(), bgColor);
		if (direction == up_)
			FillArea(i->x, i->y + i->velocity(), L' ', i->preImg().getWidth(), i->preImg().getHeight(), bgColor);
		if (direction == down_)
			FillArea(i->x, i->y - i->velocity(), L' ', i->preImg().getWidth(), i->preImg().getHeight(), bgColor);

		if (i->x < 0)
			i->x = ScreenWidth - 1 - offset_box - i->curImg().getWidth();

		if (i->x + i->curImg().getWidth() > ScreenWidth - offset_box) 
			i->x = 0;
	} 
}
void Game::drawObject()
{
	for (auto i : obstacleList)
		drawPicture(i->x, i->y, i->curImg(), bgColor | i->getColor());

	for (auto i : lights)
	{
		i->run();
		drawPicture(i->x, i->y, trafficLight, bgColor | FG_DARK_GREY);
		if (i->isStop())
		{
			setPosColor(i->x + 1, i->y + 1, COLOUR::BG_RED | FG_RED);
			for (auto j : obstacleList)
				if (i->sameLine(j)) 
					j->is_moving = false;
		}
		else
		{
			setPosColor(i->x + 1, i->y + 2, COLOUR::BG_GREEN | FG_GREEN);
			for (auto j : obstacleList)
				if (i->sameLine(j))
					j->is_moving = true;
		}
	}
}
void Game::drawPlayer()
{
	player->playAnim();
	drawPicture(player->x, player->y, player->curImg(), bgColor | player->getColor()); // we can change this later
}
void Game::loadLevel(int level)
{
	int _x, _y, _velocity;
	string _type = "", _dir = "";
	fstream file("Levels/level" + to_string(level) + ".txt", ios::in);
	while (!file.eof())
	{
		file >> _type;
		if (_type == "Car" || _type == "Truck" || _type == "Deer" || _type == "Bird")
		{
			file >> _x >> _y >> _dir >> _velocity;
			if (_type == "Car")
			{
				if (_dir == "right")
					obstacleList.push_back(new Car(_x, _y, right_, _velocity));
				else
					obstacleList.push_back(new Car(_x, _y, left_, _velocity));
			}
			else if (_type == "Truck")
			{
				if (_dir == "right")
					obstacleList.push_back(new Truck(_x, _y, right_, _velocity));
				else
					obstacleList.push_back(new Truck(_x, _y, left_, _velocity));
			}
			else if (_type == "Deer")
			{
				if (_dir == "right")
					obstacleList.push_back(new Deer(_x, _y, right_, _velocity));
				else
					obstacleList.push_back(new Deer(_x, _y, left_, _velocity));
			}
			else if (_type == "Bird")
			{
				if (_dir == "right")
					obstacleList.push_back(new Bird(_x, _y, right_, _velocity));
				else
					obstacleList.push_back(new Bird(_x, _y, left_, _velocity));
			}
		}
		else if (_type == "lights")
		{
			int tR = 0, tG = 0;
			file >> _x >> _y >> tR >> tG;
			lights.push_back(new TrafficLight(_x, _y, tR, tG));
		}
	}
	file.close();
}
void Game::drawGame()
{
	while (state == playGame)
	{
		int countCar = 0, countTruck = 0, countBird = 0, countDeer = 0;
		// counting stuff
		for (auto i : obstacleList)
		{
			if (i->getName() == "Car") countCar++;
			else if (i->getName() == "Bird") countBird++;
			else if (i->getName() == "Deer") countDeer++;
			else countTruck++;
		}
		drawBorder();
		updatePosObject();

		if (!updatePosPlayer(MOVING))
			break;
		MOVING = ' '; // avoid further moving

		wstring hearts = L"";
		for (int i = 0; i < player->getHealth() / 10; i++)
			hearts += L'♥';
		drawButton(ScreenWidth - offset_box + 2, 30, L"W,A,S,D để di chuyển");
		drawButton(ScreenWidth - offset_box + 2, 35, L"ESC để pause game");

		drawString(ScreenWidth - offset_box + 7, 2, L"MÁU: " + hearts + L" ", bgColor | FG_GREEN);
		drawBox(ScreenWidth - offset_box + 5, 1, 19, 3, bgColor | FG_GREEN);
		drawButton(ScreenWidth - offset_box + 5, 4, L"MÀN CHƠI: " + to_wstring(player->getLevel()) + L" ", bgColor | FG_GREEN);

		drawButton(ScreenWidth - offset_box + 5, 7, L"SỐ XE HƠI: " + to_wstring(countCar) + L" ", bgColor | FG_GREEN);
		drawButton(ScreenWidth - offset_box + 5, 10, L"SỐ XE TẢI: " + to_wstring(countTruck) + L" ", bgColor | FG_GREEN);
		drawButton(ScreenWidth - offset_box + 5, 13, L"SỐ CHIM: " + to_wstring(countBird) + L" ", bgColor | FG_GREEN);
		drawButton(ScreenWidth - offset_box + 5, 16, L"SỐ NAI: " + to_wstring(countDeer) + L" ", bgColor | FG_GREEN);
		drawButton(ScreenWidth - offset_box + 5, 19, L"SỐ ĐÈN: " + to_wstring(lights.size()) + L" ", bgColor | FG_GREEN);

		// draw lines
		FillArea(1, 4, L'━', ScreenWidth - offset_box - 1, 1, bgColor | FG_DARK_GREEN);
		FillArea(1, 9, L'━', ScreenWidth - offset_box - 1, 1, bgColor | FG_DARK_GREEN);
		FillArea(1, 14, L'━', ScreenWidth - offset_box - 1, 1, bgColor | FG_DARK_GREEN);
		FillArea(1, 19, L'━', ScreenWidth - offset_box - 1, 1, bgColor | FG_DARK_GREEN);
		FillArea(1, 24, L'━', ScreenWidth - offset_box - 1, 1, bgColor | FG_DARK_GREEN);
		FillArea(1, 29, L'━', ScreenWidth - offset_box - 1, 1, bgColor | FG_DARK_GREEN);
		FillArea(1, 34, L'━', ScreenWidth - offset_box - 1, 1, bgColor | FG_DARK_GREEN);
		FillArea(1, 39, L'━', ScreenWidth - offset_box - 1, 1, bgColor | FG_DARK_GREEN);

		// draw box and bla bla
		drawBox(ScreenWidth - 30, 0, 30, ScreenHeight, bgColor | FG_MAGENTA);
		FillArea(ScreenWidth - 29, 22, L'━', 28, 1, bgColor | FG_MAGENTA); // draw a line
		addChar(ScreenWidth - 30, 20, L'┣', bgColor | FG_MAGENTA);
		addChar(ScreenWidth - 1, 20, L'┫', bgColor | FG_MAGENTA);

		drawObject();
		drawPlayer();

		for (auto i : obstacleList)
		{
			if (player->isImpact(i))
			{
				playHitSound();
				if (player->isDead()) goto game_over;

				FillArea(player->x, player->y, L' ', player->curImg().getWidth(), player->curImg().getHeight(), bgColor);
				drawPicture(player->x, player->y, explosion, bgColor | FG_DARK_RED);

				drawConsole(); // the main thing we need
				Sleep(1000); // hehe lol :33
				FillArea(player->x, player->y, L' ', player->curImg().getWidth(), player->curImg().getHeight(), bgColor);
				FillArea(player->x, player->y, L' ', explosion.getWidth(), explosion.getHeight(), bgColor);

				player->y = ScreenHeight - player->curImg().getHeight() - 1;
				player->x = (ScreenWidth - offset_box) / 2 - player->curImg().getWidth();
				break;
			}
		}
		drawConsole(); // the main thing we need
	}
game_over:
	clearConsole();
	if (player->isDead())
	{
		// clear up RAM
		for (auto i : obstacleList)
			delete i;
		obstacleList.clear();
		for (auto i : lights)
			delete i;
		lights.clear();

		state = lose;
		drawGameDead();
	}
}
void Game::drawGameWin()
{
	Animation dance = manAnimator;
	Animation dance1 = dancingAnimator;
	while (state == win)
	{
		dance.play();
		dance1.play();
		FillArea(1, 1, L' ', ScreenWidth - offset_box - 1, ScreenHeight - 2, bgColor);
		drawString((ScreenWidth - offset_box) / 2 - tomb.getWidth() - 5, ScreenHeight / 2, L"YOU WON THE GAME, PRESS ENTER TO RETURN ... ", bgColor | FG_BLUE);
		drawPicture(50, 3, winGame, bgColor | FG_DARK_RED);

		drawPicture(100, 40, dance.getCurFrame(), bgColor | FG_DARK_RED);
		drawPicture(100, 35, dance1.getCurFrame(), bgColor | FG_DARK_RED);
		drawConsole();
		clearConsole();
	}
	clearConsole();
}
void Game::drawGameDead()
{
	Animation dance = manAnimator;
	while (state == lose)
	{
		dance.play();

		FillArea(1, 1, L' ', ScreenWidth - offset_box - 1, ScreenHeight - 2, bgColor);
		drawPicture(5, 3, endGame, bgColor | FG_DARK_RED);
		drawPicture((ScreenWidth - offset_box) / 2 - tomb.getWidth(), ScreenHeight / 2 - tomb.getHeight(), tomb, bgColor | FG_DARK_GREY);
		drawString((ScreenWidth - offset_box) / 2 - tomb.getWidth() - 5, ScreenHeight / 2, L"PRESS ENTER TO RETURN TO MENU ... ", bgColor | FG_BLUE);
		drawPicture((ScreenWidth - offset_box) / 2 - tomb.getWidth(), ScreenHeight / 2 + 3, ded_man, bgColor | FG_DARK_GREY);
		drawPicture(100, 40, dance.getCurFrame(), bgColor | FG_DARK_RED);
		drawConsole();
	}
	clearConsole();
}